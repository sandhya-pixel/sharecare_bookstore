export class Donation {
    constructor(
        public demail:string,
        public ddate:string,
        public paymentmode:string,
        public amount:number
    ){}

}
