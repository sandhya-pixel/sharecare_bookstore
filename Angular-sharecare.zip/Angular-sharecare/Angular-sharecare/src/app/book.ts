export class Book {
      bookId: Number;
      bookTitle: String;
      bookAuthor: String;
      noOfPages: Number;
      bookDescription: String;
      categoryName: String;
      adminApproval: String;

}
