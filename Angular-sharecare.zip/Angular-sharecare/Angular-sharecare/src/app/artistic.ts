export class Artistic {
      constructor(
            //  public email: string,
            public content: string
      ) { }

}
