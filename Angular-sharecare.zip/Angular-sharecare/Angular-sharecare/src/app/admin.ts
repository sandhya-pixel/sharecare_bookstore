export class Admin {


      adminEmail: string;
      adminPassword: string;

      constructor() {

      }
}
