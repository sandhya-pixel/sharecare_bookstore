export class Contactus {
      cemail: String;
      message: String;
}
