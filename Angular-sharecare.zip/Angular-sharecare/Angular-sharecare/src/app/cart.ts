export class Cart {
      cartid: Number;
      bookTitle: String;
      bookAuthor: String;
      id: Number;
      bookId: Number;

      constructor() {
            this.cartid = 0;
            this.bookTitle = "";
            this.bookAuthor = "";
            this.id = 0;
            this.bookId = 0;

      }
}
