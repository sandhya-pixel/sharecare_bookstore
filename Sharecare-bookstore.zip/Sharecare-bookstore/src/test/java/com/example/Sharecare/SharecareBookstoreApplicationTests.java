package com.example.Sharecare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharecareBookstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
