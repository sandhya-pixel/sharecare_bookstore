package com.Sharecare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SharecareBookstoreApplication {

	public static void main(String[] args) {
		
		
	SpringApplication.run(SharecareBookstoreApplication.class, args);
	
	
	}

}
