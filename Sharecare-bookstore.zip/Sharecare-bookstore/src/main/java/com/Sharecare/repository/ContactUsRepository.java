package com.Sharecare.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Sharecare.model.ContactUs;

public interface ContactUsRepository extends JpaRepository<ContactUs, String> {

}
